#!/usr/bin/env bash
# deploy.sh - bootstrap and run FruGo locally with Docker
set -euo pipefail

GREEN='[0;32m'; YELLOW='[1;33m'; RED='[0;31m'; NC='[0m'
info()  { echo -e "${GREEN}[INFO]${NC}  $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

info "Checking prerequisites..."
command -v docker >/dev/null 2>&1 || error "Docker is not installed."
COMPOSE="docker compose"
docker compose version >/dev/null 2>&1 || COMPOSE="docker-compose"

if [ ! -f .env ]; then
    info "Creating .env from .env.example..."
    cp .env.example .env
    warn "Please review .env and update DB credentials if needed."
fi

info "Building and starting containers..."
$COMPOSE -f deployment/docker-compose.yml up -d --build

info "Waiting for database to be ready..."
MAX=30; N=0
until $COMPOSE -f deployment/docker-compose.yml exec -T db mysqladmin ping -h localhost --silent 2>/dev/null; do
    N=$((N+1)); [ "$N" -ge "$MAX" ] && error "Database did not become ready in time."
    echo -n "."; sleep 2
done
echo ""; info "Database is ready."

info "Generating application key..."
$COMPOSE -f deployment/docker-compose.yml exec -T app php artisan key:generate --force

info "Running migrations..."
$COMPOSE -f deployment/docker-compose.yml exec -T app php artisan migrate --force

info "Seeding database..."
$COMPOSE -f deployment/docker-compose.yml exec -T app php artisan db:seed --force

info "Setting up storage..."
$COMPOSE -f deployment/docker-compose.yml exec -T app php artisan storage:link
$COMPOSE -f deployment/docker-compose.yml exec -T app chown -R www-data:www-data /var/www/storage /var/www/bootstrap/cache

echo ""
info "FruGo is running at: http://localhost:8080"
info "MailHog (dev emails): http://localhost:8025"
info ""
info "Demo accounts:"
info "  Admin:   admin@example.com   / Admin@1234"
info "  Manager: manager@example.com / Manager@1234"
